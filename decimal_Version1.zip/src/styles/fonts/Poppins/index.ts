export { default as Poppins_300 } from './Poppins-Light.ttf'
export { default as Poppins_400 } from './Poppins-Regular.ttf'
export { default as Poppins_500 } from './Poppins-Medium.ttf'
export { default as Poppins_600 } from './Poppins-SemiBold.ttf'